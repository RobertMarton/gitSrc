#http://wiki.baidu.com/pages/viewpage.action?pageId=1071523208
cur_time=`date  +"%Y%m%d%H%M"`
job_name=demo_job${cur_time}
 
# args
group_name="k8s-dev-new-api" # 将作业提交到group_name指定的组，必填
job_version="pytorch-1.3.0"
start_cmd="sh train.sh"
wall_time="2:00:00"
file_dir="."
 
baichuan submit --job-name ${job_name} \
        --queue-name ${group_name} \
        --job-conf config.ini \
        --start-cmd "${start_cmd}" \
        --file-dir ${file_dir} \
        --job-version ${job_version} \
        --time-limit 120 \
        --priority "high" \
        --num-nodes 2 \
        --gpu-pnode 1 \
        --is-standalone 0 \
        --distribute-job-type "NCCL2"\
        --k8s
