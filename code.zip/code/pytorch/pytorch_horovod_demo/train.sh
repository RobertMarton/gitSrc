#!/bin/bash
set -x
source ~/.bashrc
export LD_LIBRARY_PATH=/opt/conda/envs/py36/lib/python3.6/site-packages/torch/lib/:$LD_LIBRARY_PATH
export LD_LIBRARY_PATH=/opt/conda/envs/py27/lib/python2.7/site-packages/torch/lib/:$LD_LIBRARY_PATH

# pytorch 1.3.0 需要降低 Pillow 的版本， pytorch 1.4.0 无此问题
if [[ "${SYS_JOB_VERSION}" = "pytorch-1.3.0" ]]; then
    mpirun /opt/conda/envs/py36/bin/python -m pip install Pillow==6.2.2
fi

mpirun -x HOROVOD_MPI_THREADS_DISABLE=1 \
       -x NCCL_IB_HCA=eth2 \
       --mca pml ^ucx \
       /opt/conda/envs/py36/bin/python pytorch_imagenet_resnet50.py \
       --train-dir afs/train_data/imagenet/train \
       --val-dir afs/train_data/imagenet/val
if [[ $? -ne 0 ]]; then
    echo "train failed"
    exit 1
fi
exit 0
