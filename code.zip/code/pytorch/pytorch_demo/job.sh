#!/bin/bash
# 系统环境变量 wiki: http://wiki.baidu.com/pages/viewpage.action?pageId=1071523004
current_rank_index=${POD_INDEX}
rank_0_ip=${POD_0_IP}
free_port=${TRAINER_PORTS}
dist_url="tcp://${rank_0_ip}:${free_port}"
world_size=2
echo "current_rank_index: ${current_rank_index}"
echo "dist_url: ${dist_url}"
echo "world_size: ${dist_url}"

lsof -i:${free_port}

function switch_py36() {
    # switch python3
    export PY36_HOME=/opt/conda/envs/py36
    export PATH=${PY36_HOME}/bin:$PATH
    export LD_LIBRARY_PATH=${PY36_HOME}/lib/:${LD_LIBRARY_PATH}
}

function py27_local() {
    # default py27
    echo "this is py27 local train job..."
    python train.py -a resnet18 ./afs/imagenet2012
}

function py36_local() {
    echo " this is py36 local train job..."
    switch_py36
    # pytorch 1.3.0 需要降低 Pillow 的版本， pytorch 1.4.0 无此问题
    pip install Pillow==6.2.2
    python train.py -a resnet18 ./afs/imagenet2012
}

function py36_local_multicard() {
    # pytorch spawn 只支持 py3.4 或者个更高，因此该实例单机多卡，仅跑 py3
    echo "this is py36 local multicard train job..."
    switch_py36
    # pytorch 1.3.0 需要降低 Pillow 的版本， pytorch 1.4.0 无此问题
    pip install Pillow==6.2.2
    python train.py -a resnet50 --dist-url ${dist_url} --dist-backend 'nccl' --multiprocessing-distributed --world-size 1 --rank 0 ./afs/imagenet2012

}

function py36_distribute() {
    # pytorch spawn 只支持 py3.4 或者个更高，因此该实例单机多卡，仅跑 py3
    echo "this is py36 distribute train job..."
    switch_py36
    # pytorch 1.3.0 需要降低 Pillow 的版本， pytorch 1.4.0 无此问题
    pip install Pillow==6.2.2
    python train.py -a resnet50 \
                    --dist-url ${dist_url} \
                    --dist-backend 'nccl' \
                    --multiprocessing-distributed \
                    --world-size ${world_size} \
                    --rank ${current_rank_index} ./afs/imagenet2012
}

function main() {
    if [[ "${IS_STANDALONE}" = "1" ]]; then
        echo "this is local mode job, will run py27 and py36 local train job..."
        if [[ "${TRAINER_GPU_CARD_COUNT}" = "1" ]]; then
            echo "this one gpu card train job..."
            py27_local
            sleep 2
            py36_local
        else
            echo "this multi gpu card train job..."
            py36_local_multicard
        fi
    else
        echo " this is distribute train job..."
        py36_distribute
    fi
    echo "finished!"
}

main
