#!/bin/bash
###############################################################
##                  注意--注意--注意                         ##
##                  pytorch NCCL2多机作业演示                ##
###############################################################
cur_time=`date  +"%Y%m%d%H%M"`

# 作业名请填写您已注册过的名字
job_name=feed_production_day_k8s_test${cur_time}
echo "job_name: "$job_name 
# 作业参数
group_name="feed-0-yq01-k8s-gpu-p40-8"                   # 将作业提交到group_name指定的组，必填
job_version="pytorch-1.4.0"
start_cmd="sh job.sh"
file_dir="."
k8s_gpu_cards=1
k8s_priority="normal"
k8s_trainers=2
 
baichuan submit --job-name ${job_name} \
        --queue-name ${group_name} \
        --job-conf config.ini \
        --start-cmd "${start_cmd}" \
        --file-dir ${file_dir} \
        --job-version ${job_version}  \
        --num-nodes 2 \
        --gpu-pnode ${k8s_gpu_cards} \
        --priority ${k8s_priority} \
        --time-limit 120 \
        --is-standalone 0 \
        --ak '53c3bd87c96d5ca980ed14c9bd9e68f5'\
        --sk '03ff546e300652b2875fbaa9a1e53491'\
        --distribute-job-type "NCCL2"\
        --k8s
