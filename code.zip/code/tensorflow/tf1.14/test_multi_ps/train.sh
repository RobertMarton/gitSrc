#!/bin/bash
#export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/home/opt/nvidia_lib 
#env
trainer_hosts=""
#for ip in ${TRAINER_INSTANCES//,/ }
for ip in ${TRIANER_IP_LIST//,/ }
do
    port0=`echo $TRAINER_PORTS | awk -F',' '{print $1}' | sed 's/ //g'`
    trainer_hosts=$trainer_hosts","$ip":"$port0
done
trainer_hosts=${trainer_hosts#*,}
echo "trainer_hosts: $trainer_hosts"

pserver_hosts=""
#for ip in ${PSERVER_INSTANCES//,/ }
for ip in ${PSERVER_IP_LIST//,/ }
do
    port0=`echo $PSERVER_PORTS | awk -F',' '{print $1}' | sed 's/ //g'`
    pserver_hosts=$pserver_hosts","$ip":"$port0
done
pserver_hosts=${pserver_hosts#*,}
echo "pserver_hosts: $pserver_hosts"


if [ "${TRAINING_ROLE}" = "PSERVER" ]
then
  echo "==== run ps server ===="
  #export CUDA_VISIBLE_DEVICES=
  #/opt/conda/envs/py36/bin/python mnist_replica.py \
  /opt/conda/envs/py27/bin/python mnist_replica.py \
    --num_gpus=1 \
    --data_dir=afs/train_data \
    --job_name=ps \
    --ps_hosts=${pserver_hosts}\
    --worker_hosts=${trainer_hosts}\
    --task_index=${POD_INDEX}
fi

if [ "${TRAINING_ROLE}" = "TRAINER" ]
then
  echo "==== run trainer ===="
  sleep 5
  #/opt/conda/envs/py36/bin/python mnist_replica.py \
  /opt/conda/envs/py27/bin/python mnist_replica.py \
    --num_gpus=1 \
    --data_dir=afs/train_data \
    --job_name=worker \
    --ps_hosts=${pserver_hosts}\
    --worker_hosts=${trainer_hosts}\
    --task_index=${POD_INDEX}
fi
