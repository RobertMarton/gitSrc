#!/bin/bash
set -x
# 使平台设置的 alias mpirun 在当前 shell 空间生效
#source ~/.bashrc
mpirun mkdir -p /root/.keras/datasets
mpirun cp `pwd`/afs/train_data/* /root/.keras/datasets/
mpirun -x NCCL_IB_HCA=eth2 /opt/conda/envs/py27/bin/python tensorflow_mnist_2.py
if [[ $? -ne 0 ]]; then
    echo "train failed"
    exit 1
fi

exit 0
