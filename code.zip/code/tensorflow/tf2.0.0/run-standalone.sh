#!/bin/bash
###############################################################
##                  注意-- 注意--注意                        ##
##                  tf2.0.0 单机作业示例                   ##
###############################################################
cur_time=`date  +"%Y%m%d%H%M"`
job_name=demo_job${cur_time}

# 作业参数
group_name=""                   # 将作业提交到group_name指定的组，必填
job_version='tensorflow-2.0.0'

start_cmd="sh train.sh"
wall_time="10:00:00"
k8s_priority="normal"
file_dir="."

baichuan submit --job-name ${job_name} \
        --queue-name ${group_name} \
        --job-conf config.ini \
        --start-cmd "${start_cmd}" \
        --file-dir ${file_dir} \
        --job-version ${job_version}  \
        --priority ${k8s_priority} \
        --time-limit 120 \
        --is-standalone 1\
        --k8s  
