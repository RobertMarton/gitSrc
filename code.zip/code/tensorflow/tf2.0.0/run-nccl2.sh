#!/bin/bash
#http://wiki.baidu.com/pages/viewpage.action?pageId=1071523265
###############################################################
##                  注意-- 注意--注意                        ##
##                  tf2.0.0 nccl2多机作业示例                   ##
###############################################################
cur_time=`date  +"%Y%m%d%H%M"`
job_name=demo_job${cur_time}

# 作业参数
group_name="feed-0-yq01-k8s-gpu-p40-8"                   # 将作业提交到group_name指定的组，必填
job_version='tensorflow-2.0.0'

start_cmd="sh train.sh"
wall_time="10:00:00"
k8s_priority="normal"
file_dir="."

baichuan submit --job-name ${job_name} \
        --queue-name ${group_name} \
        --job-conf config.ini \
        --start-cmd "${start_cmd}" \
        --file-dir ${file_dir} \
        --job-version ${job_version}  \
        --priority ${k8s_priority} \
        --time-limit 120 \
        --num-nodes 2 \
        --gpu-pnode 1 \
        --is-standalone 0 \
        --distribute-job-type "NCCL2"\
        --k8s
